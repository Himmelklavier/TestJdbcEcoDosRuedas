package c2r5;

public class C2R5 {

    public static void main(String[] args) {
        
        Graphics.main(args);
        
    }
    
}
