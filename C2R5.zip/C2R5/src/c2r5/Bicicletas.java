package c2r5;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bicicletas extends javax.swing.JInternalFrame {

    public int idBicicletas;
    public String fabricante;
    public String precioUnitario;
    public int anno;
    ArrayList<Bicicletas> bicisRegistradas = new ArrayList<>();

    public Bicicletas(int idBicicletas, String fabricante, String precioUnitario, int anno) {
        this.idBicicletas = idBicicletas;
        this.fabricante = fabricante;
        this.precioUnitario = precioUnitario;
        this.anno = anno;
    }

    public int getIdBicicletas() {
        return idBicicletas;
    }

    public void setIdBicicletas(int idBicicletas) {
        this.idBicicletas = idBicicletas;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(String precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getAnno() {
        return anno;
    }

    public void setAnno(int anno) {
        this.anno = anno;
    }

    public boolean crearBicicleta() {
        Connection conn = Conexion.conectar();
        String sql = "insert into bicicletas VALUES (? ,? , ?, ? )";
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, Integer.parseInt(jTxtIdBicis.getText()));
            statement.setString(2, jTxtFabricantes.getText());
            statement.setString(3, jTxtPrecioUnidad.getText());
            statement.setInt(4, Integer.parseInt(jTxtAño.getText()));
            int rowsInserted = statement.executeUpdate();
            conn.close();
            verBicicletas();
            if (rowsInserted > 0) {
                return true;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex);

            //JOptionPane.showMessageDialog(null, "Error insertando bicicleta");
        }
        return false;
    }

    public ArrayList verBicicletas() throws SQLException {
        limpiarTabla();
        bicisRegistradas.clear();
        Connection conn = Conexion.conectar();
        String sql = "select * from bicicletas";
        Statement statement = conn.createStatement();
        ResultSet result = statement.executeQuery(sql);
        while (result.next()) {
            int id = result.getInt(1);
            String fabric = result.getString(2);
            String valorUnitario = result.getString(3);
            int año = result.getInt(4);
            Bicicletas b = new Bicicletas(id, fabric, valorUnitario, año);

            bicisRegistradas.add(b);
        }
        try {
            String datos[][] = new String[bicisRegistradas.size()][4];
            for (int i = 0; i < bicisRegistradas.size(); i++) {
                datos[i][0] = String.valueOf(bicisRegistradas.get(i).idBicicletas);
                datos[i][1] = bicisRegistradas.get(i).fabricante;
                datos[i][2] = bicisRegistradas.get(i).precioUnitario;
                datos[i][3] = String.valueOf(bicisRegistradas.get(i).anno);
            }
            jTableBicicletas.setModel(new javax.swing.table.DefaultTableModel(
                    datos, new String[]{
                        "Id Bicicleta", "Fabricante", "Precio unitario", "Año"
                    }));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        return bicisRegistradas;
    }

    public void limpiarTabla() {
        jTxtIdBicis.setText("");
        jTxtFabricantes.setText("");
        jTxtPrecioUnidad.setText("");
        jTxtAño.setText("");
        String vacio[][] = {{"", "", "", ""}, {"", "", "", ""}};
        jTableBicicletas.setModel(new javax.swing.table.DefaultTableModel(
                vacio, new String[]{
                    "Id Bicicleta", "Fabricante", "Precio unitario", "Año"
                }));
    }

    public Bicicletas() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTxtIdBicis = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTxtPrecioUnidad = new javax.swing.JTextField();
        jTxtAño = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTxtFabricantes = new javax.swing.JTextField();
        jBtnCrear = new javax.swing.JButton();
        jBtnLeer = new javax.swing.JButton();
        jBtnUpdate = new javax.swing.JButton();
        jBtnDelete = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableBicicletas = new javax.swing.JTable();
        jBtnLimpiar = new javax.swing.JButton();

        jLabel1.setText("Fabricante");

        jTxtAño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtAñoActionPerformed(evt);
            }
        });

        jLabel2.setText("Precio unitario");

        jLabel3.setText("Año");

        jLabel4.setBackground(new java.awt.Color(240, 222, 147));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("   Bicicletas                  ECODOSRUEDAS                          2022");
        jLabel4.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel5.setText("Identificador");

        jBtnCrear.setText("Crear");
        jBtnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCrearActionPerformed(evt);
            }
        });

        jBtnLeer.setText("Leer");
        jBtnLeer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnLeerActionPerformed(evt);
            }
        });

        jBtnUpdate.setText("Actualizar");
        jBtnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnUpdateActionPerformed(evt);
            }
        });

        jBtnDelete.setText("Eliminar");
        jBtnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnDeleteActionPerformed(evt);
            }
        });

        jTableBicicletas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id Bicicleta", "Fabricante", "Valor Unitario", "Año"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTableBicicletas);

        jBtnLimpiar.setText("Limpiar");
        jBtnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 726, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jBtnCrear, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(56, 56, 56)
                                        .addComponent(jBtnLeer, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel5))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(151, 151, 151)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTxtAño, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTxtPrecioUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTxtIdBicis, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTxtFabricantes, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(55, 55, 55)
                                        .addComponent(jBtnUpdate)
                                        .addGap(52, 52, 52)
                                        .addComponent(jBtnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(52, 52, 52)
                                        .addComponent(jBtnLimpiar))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 695, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addGap(58, 58, 58)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtIdBicis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTxtFabricantes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTxtPrecioUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTxtAño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnCrear)
                    .addComponent(jBtnDelete)
                    .addComponent(jBtnUpdate)
                    .addComponent(jBtnLeer)
                    .addComponent(jBtnLimpiar))
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTxtAñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtAñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtAñoActionPerformed

    private void jBtnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnUpdateActionPerformed
        //update cliente set celular = "3115678432" where alias="ninja";
        /*
        try {
            String delete = "delete from bicicletas where idBicicletas = ? ";
            PreparedStatement sentencia = conn.prepareStatement(delete);
            sentencia.setString(1, idBorrar);
            int rowsDeleted = sentencia.executeUpdate();
            conn.close();
            limpiarTabla();
            verBicicletas();
        } catch (SQLException ex) {
            Logger.getLogger(Bicicletas.class.getName()).log(Level.SEVERE, null, ex);
        }
         */
        int filaseleccionada = jTableBicicletas.getSelectedRow();
        String idActualizar;
        if (filaseleccionada != -1) {
            idActualizar = ((String) jTableBicicletas.getValueAt(filaseleccionada, 0));
            try {
                Connection conn = Conexion.conectar();
                String update1 = "update bicicletas set Fabricante = ? where idBicicletas = ? ";
                PreparedStatement sentencia1 = conn.prepareStatement(update1);
                String FabricanteUpdated=JOptionPane.showInputDialog("Escriba el nuevo valor para Fabricante: ");
                sentencia1.setString(1, FabricanteUpdated);
                sentencia1.setString(2, idActualizar);
                int rowsUpdated1 = sentencia1.executeUpdate();
                String update2 = "update bicicletas set Precio_unitario = ? where idBicicletas = ? ";
                PreparedStatement sentencia2 = conn.prepareStatement(update2);
                String vrUnitUpdated=JOptionPane.showInputDialog("Escriba el nuevo valor para Precio unitario: ");
                sentencia2.setString(1, vrUnitUpdated);
                sentencia2.setString(2, idActualizar);
                int rowsUpdated2 = sentencia2.executeUpdate();
                String update3 = "update bicicletas set Año = ? where idBicicletas = ? ";
                PreparedStatement sentencia3 = conn.prepareStatement(update3);
                String annoUpdated=JOptionPane.showInputDialog("Escriba el nuevo valor para Año: ");
                sentencia3.setString(1, annoUpdated);
                sentencia3.setString(2, idActualizar);
                int rowsUpdated3 = sentencia3.executeUpdate();
                conn.close();
                limpiarTabla();
                verBicicletas();
            } catch (SQLException ex) {
                Logger.getLogger(Bicicletas.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Debe seleccionar una fila");
        }//16:12 voy aquí, ya toma datos del txt ahora se requiere cambiarlos en la BD
        //update bicicletas set value where alias = selected row
        //ya update from table, fatla delete from bd


    }//GEN-LAST:event_jBtnUpdateActionPerformed

    private void jBtnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCrearActionPerformed
        crearBicicleta();
    }//GEN-LAST:event_jBtnCrearActionPerformed

    private void jBtnLeerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnLeerActionPerformed
        try {
            limpiarTabla();
            verBicicletas();
        } catch (SQLException ex) {
            Logger.getLogger(Bicicletas.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jBtnLeerActionPerformed

    private void jBtnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnDeleteActionPerformed
        int filaseleccionada = jTableBicicletas.getSelectedRow();
        String idBorrar;
        if (filaseleccionada != -1) {
            //Get el idBicicletas y llevar como int a idBorrar
            idBorrar = ((String) jTableBicicletas.getValueAt(filaseleccionada, 0));
            try {
                Connection conn = Conexion.conectar();
                String delete = "delete from bicicletas where idBicicletas = ? ";
                PreparedStatement sentencia = conn.prepareStatement(delete);
                sentencia.setString(1, idBorrar);
                int rowsDeleted = sentencia.executeUpdate();
                conn.close();
                limpiarTabla();
                verBicicletas();
            } catch (SQLException ex) {
                Logger.getLogger(Bicicletas.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Debe seleccionar una fila");
        }
    }//GEN-LAST:event_jBtnDeleteActionPerformed

    private void jBtnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnLimpiarActionPerformed
        limpiarTabla();
    }//GEN-LAST:event_jBtnLimpiarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnCrear;
    private javax.swing.JButton jBtnDelete;
    private javax.swing.JButton jBtnLeer;
    private javax.swing.JButton jBtnLimpiar;
    private javax.swing.JButton jBtnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableBicicletas;
    private javax.swing.JTextField jTxtAño;
    private javax.swing.JTextField jTxtFabricantes;
    private javax.swing.JTextField jTxtIdBicis;
    private javax.swing.JTextField jTxtPrecioUnidad;
    // End of variables declaration//GEN-END:variables
}
